"""Plotting entry points."""
